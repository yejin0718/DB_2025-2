CREATE TABLE 회원 (
    회원아이디 VARCHAR2(20) NOT NULL,
    비밀번호 VARCHAR2(20) NOT NULL,
    이름 VARCHAR2(20) NOT NULL,
    전화번호 VARCHAR2(11) NOT NULL,
    이메일 VARCHAR2(30),
    회원유형 NUMBER DEFAULT 0 NOT NULL,
    회원상태 NUMBER DEFAULT 0 NOT NULL,
    PRIMARY KEY (회원아이디)
);

select * from 회원;

CREATE TABLE 장르 (
    장르아이디 VARCHAR2(20) NOT NULL,
    장르명 VARCHAR2(10) NOT NULL,
    PRIMARY KEY (장르아이디)
);

select * from 장르;

CREATE TABLE 관람등급 (
    관람등급아이디 VARCHAR2(20) NOT NULL,
    관람등급명 VARCHAR2(10) NOT NULL,
    PRIMARY KEY (관람등급아이디)
);

select * from 관람등급;

CREATE TABLE 영화 (
    영화아이디 VARCHAR2(20) NOT NULL,
    영화명 VARCHAR2(20) NOT NULL,
    영화이미지 VARCHAR2(40) NOT NULL,
    러닝타임 NUMBER NOT NULL,
    가격 NUMBER NOT NULL,
    장르아이디 VARCHAR2(20) NOT NULL,
    관람등급아이디 VARCHAR2(20) NOT NULL,
    PRIMARY KEY (영화아이디),
    foreign key(장르아이디) references 장르(장르아이디),
    foreign key(관람등급아이디) references 관람등급(관람등급아이디)
);

select * from 영화;

CREATE TABLE 영화관 (
    영화관아이디 VARCHAR2(20) NOT NULL,
    영화관명 VARCHAR2(20) NOT NULL,
    위치 VARCHAR2(30) NOT NULL,
    전화번호 VARCHAR2(11) NOT NULL,
    PRIMARY KEY (영화관아이디)
);

select * from 영화관;


CREATE TABLE 상영관 (
    상영관아이디 VARCHAR2(20) NOT NULL,
    영화관아이디 VARCHAR2(20) NOT NULL,
    상영관명 VARCHAR2(20) NOT NULL,
    PRIMARY KEY (상영관아이디),
    foreign key(영화관아이디) references 영화관(영화관아이디)
);

select * from 상영관;

CREATE TABLE 좌석 (
    좌석아이디 VARCHAR2(20) NOT NULL,
    상영관아이디 VARCHAR2(20) NOT NULL,
    좌석번호 VARCHAR2(5) NOT NULL,
    PRIMARY KEY (좌석아이디),
    foreign key(상영관아이디) references 상영관(상영관아이디)
);

select * from 좌석;

CREATE TABLE 상영정보 (
    상영정보아이디 VARCHAR2(20) NOT NULL,
    영화아이디 VARCHAR2(20) NOT NULL,
    상영관아이디 VARCHAR2(20) NOT NULL,
    상영시작일자 DATE NOT NULL,
    상영종료일자 DATE NOT NULL,
    상영상태 NUMBER NOT NULL,
    PRIMARY KEY (상영정보아이디),
    foreign key(영화아이디) references 영화(영화아이디),
    foreign key(상영관아이디) references 상영관(상영관아이디)
);

select * from 상영정보;

CREATE TABLE 예약 (
    예약아이디 VARCHAR2(20) NOT NULL,
    회원아이디 VARCHAR2(20) NOT NULL,
    상영정보아이디 VARCHAR2(20) NOT NULL,
    예약일시 DATE NOT NULL,
    결제상태 NUMBER DEFAULT 0 NOT NULL,
    PRIMARY KEY (예약아이디),
    foreign key(회원아이디) references 회원(회원아이디),
    foreign key(상영정보아이디) references 상영정보(상영정보아이디)
);

select * from 예약;

CREATE TABLE 예약좌석 (
    예약좌석아이디 VARCHAR2(20) NOT NULL,
    예약아이디 VARCHAR2(20) NOT NULL,
    좌석아이디 VARCHAR2(20) NOT NULL,
    PRIMARY KEY (예약좌석아이디),
    foreign key(예약아이디) references 예약(예약아이디),
    foreign key(좌석아이디) references 좌석(좌석아이디)
);

select * from 예약좌석;
