create user "C##yejin" IDENTIFIED by "1234";

grant dba, resource, connect to "C##yejin";

CREATE TABLE 회원 (
    회원아이디 VARCHAR2(20) NOT NULL,
    비밀번호 VARCHAR2(20) NOT NULL,
    이름 VARCHAR2(20) NOT NULL,
    나이 NUMBER,
    직업 VARCHAR2(20),
    등급 VARCHAR2(20) DEFAULT 'silver' NOT NULL,
    적립금 NUMBER DEFAULT 0 NOT NULL,
    PRIMARY KEY (회원아이디),
    CHECK (나이 >= 0),
    CHECK (등급 IN ('silver', 'gold', 'vip'))
);

select * from 회원;

CREATE TABLE 상품 (
    상품번호 VARCHAR2(20) NOT NULL,
    상품명 VARCHAR2(20) NOT NULL,
    재고량 NUMBER DEFAULT 0 NOT NULL,
    단가 NUMBER DEFAULT 0 NOT NULL,
    제조업체명 VARCHAR2(20) NOT NULL,
    공급일자 DATE NOT NULL,
    공급량 NUMBER DEFAULT 0 NOT NULL,
    PRIMARY KEY (상품번호),
    CHECK (재고량 >= 0),
    CHECK (단가 >= 0)
);
select * from 상품;

CREATE TABLE 제조업체 (
    제조업체명 VARCHAR2(20) NOT NULL,
    전화번호 VARCHAR2(12) NOT NULL,
    위치 VARCHAR2(20) NOT NULL,
    담당자 varchar(10) NOT NULL,
    PRIMARY KEY (제조업체명)
);
select * from 제조업체;

CREATE TABLE 게시글 (
    글번호 VARCHAR2(20) NOT NULL,
    글제목 VARCHAR2(30) NOT NULL,
    글내용 VARCHAR2(100) NOT NULL,
    작성일자 date NOT NULL,
    회원아이디 VARCHAR2(20) NOT NULL,
    PRIMARY KEY (글번호),
    foreign key(회원아이디) references 회원(회원아이디)
);
select * from 게시글;

CREATE TABLE 주문 (
    주문번호 VARCHAR2(20) NOT NULL,
    상품수량 NUMBER default 0 NOT NULL,
    배송지 VARCHAR2(20) NOT NULL,
    주문일자 date NOT NULL,
    회원아이디 VARCHAR2(20) NOT NULL,
    상품번호 varchar(20) not null,
    PRIMARY KEY (주문번호),
    foreign key(회원아이디) references 회원(회원아이디),
    foreign key(상품번호) references 상품(상품번호)
);
select * from 주문;

CREATE TABLE 공급 (
    공급일자 date NOT NULL,
    공급량 NUMBER default 0 NOT NULL,
    PRIMARY KEY (공급일자)
);
select * from 공급;